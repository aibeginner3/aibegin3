class Lexicon(object):
    def lookup(self, text, offset):
        pass

    def get_left_id(self, word_id):
        pass

    def get_right_id(self, word_id):
        pass

    def get_cost(self, word_id):
        pass

    def get_word_info(self, word_id):
        pass
