from sudachipy.plugin.oov import simple_oov_plugin
from sudachipy.plugin.oov import mecab_oov_plugin
from sudachipy.plugin.path_rewrite import join_numeric_plugin
from sudachipy.plugin.path_rewrite import join_katakana_oov_plugin
from sudachipy.plugin.input_text import default_input_text_plugin
