This is a python wrapper for CaboCha. It does not sopport Windows Python 64bit version.

    License
    ---------
    CaboCha is copyrighted free software by Taku Kudo <taku@chasen.org>
is released under any of the the LGPL (see the file LGPL) or the
BSD License (see the file BSD).


