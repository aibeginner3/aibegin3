# For PyInstaller/lib/ define the version here, since there is no
# package-resource.
__version__ = '0.13'
