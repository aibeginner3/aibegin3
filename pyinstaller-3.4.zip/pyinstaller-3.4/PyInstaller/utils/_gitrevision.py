#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "0f31b35fe"     # abbreviated commit hash
commit = "0f31b35fe96de59e1a6faf692340a9ef93492472"  # commit hash
date = "2018-09-09 20:11:29 +0200"   # commit date
author = "Hartmut Goebel <h.goebel@crazy-compilers.com>"
ref_names = "tag: v3.4, master"  # incl. current branch
commit_message = """Release 3.4.
"""
