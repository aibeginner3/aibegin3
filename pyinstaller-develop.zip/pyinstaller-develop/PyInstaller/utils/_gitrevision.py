#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "170550e0c"     # abbreviated commit hash
commit = "170550e0c3d608554155a6e5261ff0c7932e686c"  # commit hash
date = "2019-05-06 21:57:00 -0500"   # commit date
author = "Bryan A. Jones <bjones@ece.msstate.edu>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """Test/CI: Revert "Pin pip to working version < 19.1."

This reverts commit 06f7da789f41a21dd697478ca317c858bc6be9e4.
A newer version of pip avoid problems introduced in pip 19.1.
"""
